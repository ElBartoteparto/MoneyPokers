import collections 
from baraja import mazo

class Jugador(object):
    def __init__(self,nombre=None):
        self.nombre = nombre
        self.cartas = []
        self.monedas = 0
        self.puntuacion = []
        self.cartaMasAlta = 0
        self.rolPartida = ""
        self.apuesta = int()
        self.pareja = []
        self.trio = []
        self.poker = []
        

    def __repr__(self):

        return "Las cartas de "+ self.nombre + " son " + self.cartas[0] + " y " + self.cartas[1]

    def info_inicio_juego(self):
        print("\n")
        self.monedas = int(input("¿Con cuantas fichas empiezas la partida ?: "))


    def evaluar(self,cartasEnMesa):

        self.pareja.clear()
        self.trio.clear()
        self.poker.clear()
        self.puntuacion.clear()

        self.cartasEnMesa = cartasEnMesa
        cartasAEvaluar = self.cartas + cartasEnMesa
        
        valores = {14:'1',2:'2',3:'3',4:'5',5:'5',6:'6',7:'7',8:'8',9:'9',10:'10',11:'J',12:'Q',13:'K'}
        palos = ["Corazones","Rombos","Treboles","Picas"]
        print("** Cartas del Jugador + Cartas en Mesa **")
        print(cartasAEvaluar)
        
        valorAEvaluar = []
        paloAEvaluar = []
        for i in range(len(cartasAEvaluar)):
            valorAEvaluar.append(cartasAEvaluar[i].valor)
            paloAEvaluar.append(cartasAEvaluar[i].palo)
        valorAEvaluar.sort()
        
        repeticionValor = collections.Counter(valorAEvaluar)
        repeticionPalo = collections.Counter(paloAEvaluar)

        """

        PAREJA,TRIO O POKER

        """
        if not self.pareja:
            self.pareja.append(0)
        
        
        for iterRepeticion in valores:
            if repeticionValor[iterRepeticion]==2:
                self.pareja.append(iterRepeticion)
                #self.puntuacion.append(2)
            elif repeticionValor[iterRepeticion]==3:
                self.trio.append(iterRepeticion)
                self.puntuacion.append(4)
            elif repeticionValor[iterRepeticion]==4:
                self.poker.append(iterRepeticion)
                self.puntuacion.append(8)
                print("Poker de {}".format(self.poker))
            else:
                pass
        
        """
        DOBLE PAREJA
        """
        self.pareja.sort(reverse=True)
        if len(self.pareja)==3:
            for punt in valores:
                if self.pareja[0]==punt:
                    self.puntuacion.append(3+0.01*punt)
                else:
                    pass
        elif len(self.pareja)<=2:
            for punt in valores:
                if self.pareja[0]==punt:
                    self.puntuacion.append(2+0.01*punt)
                else:
                    pass

        """
        FULL HOUSE
        """
        for fullHouse in range(len(self.pareja)):

            if len(self.pareja)>=1 and len(self.trio)>=1 and self.pareja[fullHouse]!=self.trio[0]:
                self.puntuacion.append(7)
        

        if not self.puntuacion:
            self.puntuacion.append(0)
            self.cartaMasAlta = max(valorAEvaluar)
        
        
        
        self.pareja.sort(reverse=True)
        
        self.trio.sort(reverse=True)

          
        # print("Parejas de {}".format(self.pareja))
        # print("Trio de {}".format(self.trio))

        """

        ESCALERA REAL DE COLOR


        """        
        numPicas, numTreboles, numRombos, numCorazones = 0,0,0,0
        cartasPicasReal, cartasTrebolesReal, cartasRombosReal, cartasCorazonesReal = [],[],[],[]
        cartasPicas,cartasTreboles,cartasRombos,cartasCorazones = [],[],[],[]
        
        for palo in palos:            
            if  repeticionPalo[palo]>=5:
                for numCarta in range(len(cartasAEvaluar)):

                    if cartasAEvaluar[numCarta].palo == 'Picas' and cartasAEvaluar[numCarta].valor>=10:
                        numPicas +=1
                        cartasPicasReal.append(cartasAEvaluar[numCarta].valor)
                    elif cartasAEvaluar[numCarta].palo == 'Treboles' and cartasAEvaluar[numCarta].valor>=10:
                        numTreboles +=1
                        cartasTrebolesReal.append(cartasAEvaluar[numCarta].valor)
                    elif cartasAEvaluar[numCarta].palo == 'Rombos' and cartasAEvaluar[numCarta].valor>=10:
                        numRombos +=1
                        cartasRombosReal.append(cartasAEvaluar[numCarta].valor)
                    elif cartasAEvaluar[numCarta].palo == 'Corazones' and cartasAEvaluar[numCarta].valor>=10:
                        numCorazones +=1
                        cartasCorazonesReal.append(cartasAEvaluar[numCarta].valor)
        if sum(cartasPicasReal) == 60:
            print("Escalera Real de Picas")
            self.puntuacion.append(10)
        elif sum(cartasTrebolesReal) == 60:
            print("Escalera Real de Treboles")
            self.puntuacion.append(10)
        elif sum(cartasRombosReal) == 60:
            print("Escalera Real de Rombos")
            self.puntuacion.append(10)
        elif sum(cartasCorazonesReal) == 60:
            print("Escalera Real de Corazones")
            self.puntuacion.append(10) 
        


        """
        ESCALERA DE COLOR NORMAL
        """

        for palo in palos:            
            if  repeticionPalo[palo]>=5:
                for numCarta in range(len(cartasAEvaluar)):

                    if cartasAEvaluar[numCarta].palo == 'Picas':
                        numPicas +=1
                        cartasPicas.append(cartasAEvaluar[numCarta].valor)
                    elif cartasAEvaluar[numCarta].palo == 'Treboles':
                        numTreboles +=1
                        cartasTreboles.append(cartasAEvaluar[numCarta].valor)
                    elif cartasAEvaluar[numCarta].palo == 'Rombos':
                        numRombos +=1
                        cartasRombos.append(cartasAEvaluar[numCarta].valor)
                    elif cartasAEvaluar[numCarta].palo == 'Corazones':
                        numCorazones +=1
                        cartasCorazones.append(cartasAEvaluar[numCarta].valor)
        
        cartasPicas.sort()
        cartasTreboles.sort()
        cartasRombos.sort()
        cartasCorazones.sort()
        if len(cartasPicas)==5:
            if cartasPicas[4]==cartasPicas[3]-1 and cartasPicas[3]==cartasPicas[2]-1 and cartasPicas[2]==cartasPicas[1]-1 and cartasPicas[1]==cartasPicas[0]-1:
                for punt in valores:
                    if max(cartasPicas)==punt:

                        self.puntuacion.append(9+0.01*punt)
                    else:
                        pass
            
        elif len(cartasTreboles)==5:
            if cartasTreboles[4]==cartasTreboles[3]-1 and cartasTreboles[3]==cartasTreboles[2]-1 and cartasTreboles[2]==cartasTreboles[1]-1 and cartasTreboles[1]==cartasTreboles[0]-1:
                for punt in valores:
                    if max(cartasTreboles)==punt:

                        self.puntuacion.append(9+0.01*punt)
                    else:
                        pass
        elif len(cartasRombos)==5:
            if cartasRombos[4]==cartasRombos[3]-1 and cartasRombos[3]==cartasRombos[2]-1 and cartasRombos[2]==cartasRombos[1]-1 and cartasRombos[1]==cartasRombos[0]-1:
                for punt in valores:
                    if max(cartasRombos)==punt:

                        self.puntuacion.append(9+0.01*punt)
                    else:
                        pass
        elif len(cartasCorazones)==5:
            if cartasCorazones[4]==cartasCorazones[3]-1 and cartasCorazones[3]==cartasCorazones[2]-1 and cartasCorazones[2]==cartasCorazones[1]-1 and cartasCorazones[1]==cartasCorazones[0]-1:
                for punt in valores:
                    if max(cartasCorazones)==punt:

                        self.puntuacion.append(9+0.01*punt)
                    else:
                        pass
        
        """
        COLOR, 5 CARTAS IGUALES
        """

        valorAEvaluar.sort(reverse=True)
        for palo in palos:            
            if  repeticionPalo[palo]>=5:
                for punt in valores:
                    if valorAEvaluar[0]==punt:
                        self.puntuacion.append(6+0.01*punt)            

        print("Monedas restantes: %s" % str(self.monedas))

        """
        CARTA MAS ALTA
        """
        
        for punt in valores:
            if valorAEvaluar[0]==punt:
                self.puntuacion.append(1+0.01*punt)
        
        self.puntuacion.sort(reverse=True)
        print(self.puntuacion)

        


                
A, B, C, D = Jugador("Fernando"), Jugador("Sofia"), Jugador("David"), Jugador("Laura")
jugadores = []
jugador1 = Jugador("Rebeca")





class Mesa(object):
    def __init__(self):
        self.cartasEnMesa = []
    
    def crear_Jugadores(self):

        while True:

            try:
                print("\n")
                num_Jugadores = int(input("¿Cuantos Jugadores vais a ser(2-6)?: "))
                if num_Jugadores >=2 and num_Jugadores <=6:
                    for num_Jugador in range(num_Jugadores): #Se crean los jugadores, pide el nombre
                        print("\n")
                        jugadores.append(Jugador(str(input("Nombre del Jugador: "))))
                break
                
            except:
                print("** No has introducido un valor correcto **")

    def reinicio_mesa(self): #Reinicio de las cartas de la mesa
        self.cartasEnMesa = []

        
mesa = Mesa()

