import random
import collections
from jugadores import Jugador, jugadores
from jugadores import mesa
from baraja import mazo    
    
class Juego(object):

    def __init__(self,jugadores):
        #self.numeroManos = 0
        self.bote = int()
        self.dealer = Jugador()
        self.ciega_pequeña = Jugador()
        self.ciega_grande = Jugador()
        self.primer_actor = Jugador()
        self.list_of_players = jugadores
        self.puntuacionesMaximas = []
        self.indexJugadorGanador = 0
        self.accion = str
        self.jugadoresQueSiguen = []
        self.jugadoresQueNoSiguen = []
        self.list_of_players_not_out = list(set(self.list_of_players))
        self.number_of_player_not_out = int(len(list(set(self.list_of_players))))

    # def establish_player_attributes(self):
    #     address_assignment = 0
    #     self.dealer = self.list_of_players_not_out[address_assignment]
    #     self.dealer.list_of_special_attributes.append("dealer")
    #     address_assignment += 1
    #     address_assignment %= len(self.list_of_players_not_out)
    #     self.small_blind = self.list_of_players_not_out[address_assignment]
    #     self.small_blind.list_of_special_attributes.append("small blind")
    #     address_assignment += 1
    #     address_assignment %= len(self.list_of_players_not_out)
    #     self.big_blind = self.list_of_players_not_out[address_assignment]
    #     self.big_blind.list_of_special_attributes.append("big blind")
    #     address_assignment += 1
    #     address_assignment %= len(self.list_of_players_not_out)
    #     self.first_actor = self.list_of_players_not_out[address_assignment]
    #     self.first_actor.list_of_special_attributes.append("first actor")
    #     self.list_of_players_not_out.append(self.list_of_players_not_out.pop(0))

    
    
    def acciones_jugador(self,listaJugadoresEnLaMano):
        self.jugadoresQueSiguen = []
        self.jugadoresQueNoSiguen = []
        apuestasMaximas = int()            
        flag = 0
        banMan = 0
        apuestas_para_comprobaciones = []

        for jugador in range(len(listaJugadoresEnLaMano)):
        
            while True:
                print("\n")
                self.accion = input("¿Que vas a hacer, {}?(Call, Fold, Raise): ".format(listaJugadoresEnLaMano[jugador].nombre))

                if self.accion == "Fold":
                    print("\n")
                    print(listaJugadoresEnLaMano[jugador].nombre + " **No sigue jugando esta mano**")
                    self.jugadoresQueNoSiguen.append(listaJugadoresEnLaMano[jugador])
                    break

                elif self.accion == "Call":
                    print("\n")
                    print(listaJugadoresEnLaMano[jugador].nombre + " **Apuesta Igualada**")
                    

                    if listaJugadoresEnLaMano[jugador].apuesta <= listaJugadoresEnLaMano[jugador].monedas:
                        self.jugadoresQueSiguen.append(listaJugadoresEnLaMano[jugador])
                        listaJugadoresEnLaMano[jugador].apuesta = apuestasMaximas
                        
                    else:
                        print("\n")
                        print("No tienes suficiente dinero")
                        self.jugadoresQueNoSiguen.append(listaJugadoresEnLaMano[jugador])
                    break

                elif self.accion == "Raise":
                    flag = 1
                    print("\n")
                    listaJugadoresEnLaMano[jugador].apuesta += int(input("¿Cuanto subes?: "))
                    apuestasMaximas += listaJugadoresEnLaMano[jugador].apuesta
                    listaJugadoresEnLaMano[jugador].apuesta = apuestasMaximas
                    self.jugadoresQueSiguen.append(listaJugadoresEnLaMano[jugador])
                    banMan = len(self.jugadoresQueSiguen)
                    print("\n")
                    print("{} ha subido la apuesta, ahora la apuesta máxima ahora es: {}.".format(listaJugadoresEnLaMano[jugador].nombre, apuestasMaximas))
                    break

                else:
                    print("\n")
                    print("No has puesto una respuesta válida, escríbelo tal cual lo pone en el request")

        
        for jugador in range(len(self.jugadoresQueSiguen)):
            apuestas_para_comprobaciones.append(self.jugadoresQueSiguen[jugador].apuesta)
        

        if collections.Counter(apuestas_para_comprobaciones)[apuestasMaximas] == len(self.jugadoresQueSiguen):

            print("Entro en el IF")
            for jugador in range(len(self.jugadoresQueSiguen)):
                self.jugadoresQueSiguen[jugador].monedas -= self.jugadoresQueSiguen[jugador].apuesta
                #self.bote += self.jugadoresQueSiguen[jugador].apuesta
            return
        
        if flag == 1:
            self.acciones_jugador_rise(apuestasMaximas, banMan)
            print(apuestasMaximas)
            for jugador in range(len(self.jugadoresQueSiguen)):
                print(self.jugadoresQueSiguen[jugador].apuesta)
        
        
        


    def acciones_jugador_rise(self, apuestasMaximas, banMan):
        apuesta = apuestasMaximas
        flagRise = 0
        banMan1 = None
        flagFold = 0
        foldMan = []
        apuestas_para_comprobaciones = []

        

        for jugador in range(len(self.jugadoresQueSiguen)):

            if jugador != banMan-1:
                if self.jugadoresQueSiguen[jugador].apuesta == apuesta:
                    pass
                else:
                    while True:
                        print("\n")
                        self.accion = input("¿Que vas a hacer, {}?(Call, Fold, Raise): ".format(self.jugadoresQueSiguen[jugador].nombre))

                        if self.accion == "Fold":
                            print("\n")
                            print(self.jugadoresQueSiguen[jugador].nombre + " **No sigue jugando esta mano**")
                            self.jugadoresQueNoSiguen.append(self.jugadoresQueSiguen[jugador])
                            foldMan.append(jugador)
                            flagFold = 1
                            break

                        elif self.accion == "Call":
                            print("\n")
                            print(self.jugadoresQueSiguen[jugador].nombre + " **Apuesta Igualada**")
                            
                            if self.jugadoresQueSiguen[jugador].apuesta <= self.jugadoresQueSiguen[jugador].monedas:
                                self.jugadoresQueSiguen[jugador].apuesta += apuesta - self.jugadoresQueSiguen[jugador].apuesta
                            
                            else:
                                print("\n")
                                print("No tienes suficiente dinero, tendrás que hacer Fold")
                                foldMan.append(jugador)


                            break

                        elif self.accion == "Raise":
                            flagRise = 1
                            banMan = 0
                            print("\n")
                            self.jugadoresQueSiguen[jugador].apuesta += int(input("¿Cuanto subes?: "))
                            apuesta += self.jugadoresQueSiguen[jugador].apuesta
                            banMan1 = jugador+1
                            print("\n")
                            print("{} la apuesta máxima ahora es {}.".format(self.jugadoresQueSiguen[jugador].nombre, apuesta))
                            break

                        else:
                            print("\n")
                            print("No has puesto una respuesta válida, escríbelo tal cual lo pone en el request")
        if flagFold == 1:
            for eliminado in range(len(foldMan)):
                self.jugadoresQueSiguen.pop(foldMan[eliminado])
            print(len(self.jugadoresQueSiguen))
            for eliminado in range(len(foldMan)):
                if foldMan[eliminado] < banMan1:
                    banMan1 -= 1
                elif foldMan[eliminado] > banMan1:
                    pass

        for jugador in range(len(self.jugadoresQueSiguen)):
            apuestas_para_comprobaciones.append(self.jugadoresQueSiguen[jugador].apuesta)

        

        if flagRise == 1:
            self.acciones_jugador_rise(apuesta, banMan1)

    def acciones_check(self):
        foldMan_check = []
        flagFold_check = 0
        flagRise_check = 0
        banMan = None
        banMan1 = 100
        bet_check = 0
        bet_flag = 0
        apuesta = 0

        
        
        for jugador in range(len(self.jugadoresQueSiguen)):
            if len(self.jugadoresQueSiguen)==1:
                return
            

            if bet_flag == 1:
                
                while True:
                    print("\n")
                    self.accion = input("¿Que vas a hacer, {}?(Call, Fold, Raise): ".format(self.jugadoresQueSiguen[jugador].nombre))

                    if self.accion == "Fold":
                        print("\n")
                        print(self.jugadoresQueSiguen[jugador].nombre + " **No sigue jugando esta mano**")
                        self.jugadoresQueNoSiguen.append(self.jugadoresQueSiguen[jugador])
                        foldMan_check.append(jugador)
                        flagFold_check = 1
                        break

                    elif self.accion == "Call":
                        print("\n")
                        print(self.jugadoresQueSiguen[jugador].nombre + " **Apuesta Igualada**")
                        
                        if self.jugadoresQueSiguen[jugador].apuesta <= self.jugadoresQueSiguen[jugador].monedas:
                            self.jugadoresQueSiguen[jugador].apuesta += apuesta - self.jugadoresQueSiguen[jugador].apuesta
                        
                        else:
                            print("\n")
                            print("No tienes suficiente dinero, tendrás que hacer Fold")
                            foldMan_check.append(jugador)


                        break

                    elif self.accion == "Raise":
                        flagRise_check = 1
                        banMan = 0
                        print("\n")
                        self.jugadoresQueSiguen[jugador].apuesta += int(input("¿Cuanto subes?: "))
                        apuesta += self.jugadoresQueSiguen[jugador].apuesta
                        banMan1 = jugador+1
                        print("\n")
                        print("{} la apuesta máxima ahora es {}.".format(self.jugadoresQueSiguen[jugador].nombre, apuesta))
                        break

                    else:
                        print("\n")
                        print("No has puesto una respuesta válida, escríbelo tal cual lo pone en el request")

            else:
                while True:
                    print("\n")
                    self.accion = input("¿Qué quieres hacer {} (Check, Fold, Bet)?: ".format(self.jugadoresQueSiguen[jugador].nombre))

                    if self.accion == "Check":
                        print("\n")
                        print("** {} hace check**".format(self.jugadoresQueSiguen[jugador].nombre))
                        break

                    elif self.accion == "Fold":
                        print("\n")
                        print(self.jugadoresQueSiguen[jugador].nombre + " **No sigue jugando esta mano**")
                        self.jugadoresQueNoSiguen.append(self.jugadoresQueSiguen[jugador])
                        foldMan_check.append(jugador)
                        flagFold_check = 1
                        break

                    elif self.accion == "Bet":
                        print("\n")
                        apuesta = int(input("¿Cuanto apuestas?: "))
                        self.jugadoresQueSiguen[jugador].apuesta = apuesta
                        bet_flag = 1
                        break
                    else: 
                        print("\n")
                        print("No has puesto una respuesta válida, escríbelo tal cual lo pone en el request")
            
            
        if flagFold_check == 1:
            for eliminado in range(len(foldMan_check)):
                self.jugadoresQueSiguen.pop(foldMan_check[eliminado])
            print(len(self.jugadoresQueSiguen))
            

            for eliminado in range(len(foldMan_check)):
                if foldMan_check[eliminado] < banMan1:
                    pass
                    #banMan1 -= 1
                elif foldMan_check[eliminado] > banMan1:
                    pass
        if bet_flag == 1 and flagRise_check == 0:
            self.acciones_jugador_rise(apuesta, banMan1)
        
        if flagRise_check == 1:
            self.acciones_jugador_rise(apuesta, banMan1)

    def reinicio_apuestas(self):
        for jugador in range(len(self.jugadoresQueSiguen)):
            self.jugadoresQueSiguen[jugador].apuesta = 0
            


    def apuestas_al_bote(self):
        
        for jugador in range(len(self.jugadoresQueSiguen)):
            #print(self.jugadoresQueSiguen[jugador].apuesta)
            self.jugadoresQueSiguen[jugador].monedas -= self.jugadoresQueSiguen[jugador].apuesta
            self.bote += self.jugadoresQueSiguen[jugador].apuesta
        print("\n")    
        print("El bote ahora es: {}".format(self.bote))
            


    def inicio_juego(self):
        for jugador in range(len(self.list_of_players)):
            self.list_of_players[jugador].info_inicio_juego()

    def juego_continuacion(self):
        print("\n")
        if input("¿Quieres continuar?")!= "":
            print("\n")
            print("El juego sigue")

    def decidir_ganador(self):
        self.puntuacionesMaximas.clear()
        for jugador in range(len(self.jugadoresQueSiguen)):
            self.puntuacionesMaximas.append(self.jugadoresQueSiguen[jugador].puntuacion[0])

        print("\n")
        print("El ganador de la mano es {}".format( self.jugadoresQueSiguen[self.puntuacionesMaximas.index(max(self.puntuacionesMaximas))].nombre))
        

    def recaudar_bote_ganador(self):
        self.jugadoresQueSiguen[self.puntuacionesMaximas.index(max(self.puntuacionesMaximas))].monedas += self.bote
        print("\n")
        print("Las monedas de {} ahora son {}".format(self.jugadoresQueSiguen[self.puntuacionesMaximas.index(max(self.puntuacionesMaximas))].nombre,self.jugadoresQueSiguen[self.puntuacionesMaximas.index(max(self.puntuacionesMaximas))].monedas))

    def evaluacion_juego(self):
        for jugador in range(len(self.jugadoresQueSiguen)):
            print("\n")
            print("\n Jugador {}".format(self.jugadoresQueSiguen[jugador].nombre))
            self.jugadoresQueSiguen[jugador].evaluar(mesa.cartasEnMesa)
    
    def eliminar_jugador(self,todosLosJugadores):

        jugadores_a_eliminar = []
        flag_eliminar = 0

        for jugador in range(len(todosLosJugadores)):
            if todosLosJugadores[jugador].monedas <= 0:
                flag_eliminar = 1
                jugadores_a_eliminar.append(jugador)
            else:
                pass
        if flag_eliminar == 1:
            for i in range(len(jugadores_a_eliminar)):
                todosLosJugadores.pop(i)

    def reinicio_jugadores(self,todosLosJugadores):
        for jugador in range(len(todosLosJugadores)):
            todosLosJugadores[jugador].cartas.clear()
            todosLosJugadores[jugador].apuesta = 0
            self.bote = 0
            




    

    

cartitas = Juego(jugadores)   


