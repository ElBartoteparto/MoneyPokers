from baraja import Carta
import random
from baraja import mazo
from jugadores import jugador1, jugadores, mesa, Jugador
from juego import cartitas
import collections

#lista_jugadores_fijos = [] 

mesa.crear_Jugadores() #Creamos los jugadores
cartitas.inicio_juego() #Determinamos las monedas con las que entran a la partida

"""
Hay que arreglar el bote para que le sume bien las monedas a la persona, le ha sumado a david 100 cuando deberia haberle sumado 200, poner lo de la apuesta inicial etc...

"""


while True:
    
    cartitas.eliminar_jugador(jugadores)
    cartitas.reinicio_jugadores(jugadores)
    mesa.reinicio_mesa()
    mazo.mezclar() 
    mazo.repartir(jugadores) #Creamos la baraja y repartimos las cartas
    
    print("")
    cartitas.acciones_jugador(jugadores)
    cartitas.apuestas_al_bote()



    """
    Flop, 3 cartas en mesa
    """
    mazo.burn()
    mazo.flop(mesa)
    print("\n")
    print("          ** CARTAS EN LA MESA: FLOP **        ")
    print("\n")
    print(mesa.cartasEnMesa)
    cartitas.reinicio_apuestas()
    cartitas.acciones_check()
    #print("EL bote es de: {} monedas".format(cartitas.bote))
    cartitas.apuestas_al_bote()
    cartitas.evaluacion_juego()
    cartitas.juego_continuacion()



    """
    Turn, 4 cartas en mesa
    """

    mazo.burn()
    mazo.turn(mesa)
    print("\n")
    print("          ** CARTAS EN LA MESA: TURN **        ")
    print("\n")
    print(mesa.cartasEnMesa)
    print("")
    cartitas.reinicio_apuestas()
    cartitas.acciones_check()
    cartitas.apuestas_al_bote()
    #print("EL bote es de: {} monedas".format(cartitas.bote))
    cartitas.evaluacion_juego()
    #cartitas.decidir_ganador()





    """
    River, 5 cartas en mesa
    """
    cartitas.juego_continuacion()
    mazo.burn()
    mazo.river(mesa)
    print("\n")
    print("          ** CARTAS EN LA MESA: RIVER **        ")
    print("\n")
    print(mesa.cartasEnMesa)
    print("")
    cartitas.reinicio_apuestas()
    cartitas.acciones_check()
    cartitas.apuestas_al_bote()
    #print("EL bote es de: {} monedas".format(cartitas.bote))
    
    cartitas.evaluacion_juego()
    cartitas.decidir_ganador()
    cartitas.recaudar_bote_ganador()


    while True:
        continuar = input("¿Quieres seguir jugando?: ")

        if continuar == "Si" or continuar == "No":
            break
        else:
            print("** Tienes que escribir Si o No **")

    if continuar == "Si":
        pass
    elif continuar == "No":
        break






    
    










