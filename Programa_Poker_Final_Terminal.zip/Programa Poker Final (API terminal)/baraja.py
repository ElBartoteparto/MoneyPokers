import random

class Carta(object):
    def __init__(self,palo,valor):
        self.palo = palo
        self.valor = valor
    
    def __repr__(self):
        return   str(self.valor) + " "+ self.palo

class Baraja(list):
    def __init__(self):
        self.cartas = []
        self.palos = ["Corazones","Rombos","Treboles","Picas"]
        self.valores = [14,2,3,4,5,6,7,8,9,10,11,12,13]

        
        for palo in self.palos:
            for valor in self.valores:
                self.cartas.append(Carta(palo,valor))
        
    def mezclar(self):
        random.shuffle(self.cartas)
        
    def repartir(self,jugadores):

        for numcartas in range(2):
            for jugador in range(len(jugadores)):
                jugadores[jugador].cartas.append(self.cartas.pop(0))


        print("\n")
        print("         ** CARTAS DE LOS JUGADORES**       ")        
        for jugador in range(len(jugadores)):
            print("\n")
            print("Las cartas de {} son {}".format(jugadores[jugador].nombre,jugadores[jugador].cartas))
            print("\n")
        
        

    def flop(self,mesa):
        
        mesa.cartasEnMesa.append(self.cartas.pop(0))
        mesa.cartasEnMesa.append(self.cartas.pop(0))
        mesa.cartasEnMesa.append(self.cartas.pop(0))
        
    
    def burn(self):
        self.cartas.pop(0)

    def turn(self,mesa):
        mesa.cartasEnMesa.append(self.cartas.pop(0))
    
    def river(self,mesa):
        mesa.cartasEnMesa.append(self.cartas.pop(0))

mazo = Baraja()

